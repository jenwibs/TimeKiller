package Cartoon;

import java.awt.event.ActionEvent;
import java.awt.*; 

public class QuitButton extends javax.swing.JButton {
	
	public QuitButton (){
		super ("I'm Ready to Be Productive");
		this.addActionListener(new QuitListener());
		this.setFont(new Font("Futura", Font.BOLD, 10));
		this.setForeground(new java.awt.Color(102, 102, 102));
		this.setFocusPainted(false);
		this.setBackground(new java.awt.Color(153, 153, 153));
		
		
		
	}


	private class QuitListener implements java.awt.event.ActionListener {
		public void actionPerformed (ActionEvent e){
			System.exit(0);
		}
	}
}
