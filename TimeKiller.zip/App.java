package Cartoon;

import javax.swing.JFrame;
import javax.swing.JPanel;
/**
 * Here's Cartoon! Your first Swing assignment!
 * Before you start coding your Cartoon, you should make sure
 * that you have a functional gfx package. Take a look at 
 * the book chapters and lecture slides for all the information 
 * you'll need (and more!).
 *
 * Jen Wibowo (jwibowo)
 * 
 *Hi, my code my have some bugs within the wrapping portion has my paintbrush composite shape is a bit odd. I also apologize
 *for any messy code/indents/commented out code that I may have missed. The animation is a bit jumpy when it wraps. I am not sure how to fix it :(.
 *When I try setting the myPb = new gfx.Paintbrush(_dp, 400, 610+) the pieces of my composite shape start to separate when it wraps. Thought that
 *the jumpiness was better then watching a bunch of pieces separate. Additionally, the window is not very responsive.
 *When resizing the window the 
 *Sorry this was late too... 
 *
 *I hope you enjoy watching the "paint dry" if you are in need of procrastinating....:)
 *
 */

public class App extends javax.swing.JFrame {	// You'll need to subclass something
	private TimeKillerFrame _timeKillerFrame;  
	private MainPanel _mainPanel; 

	public App() {
		super ("Time Killer");
		_timeKillerFrame = new TimeKillerFrame ();	
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		_mainPanel = new MainPanel ();
		getContentPane().add(_mainPanel);
		
		this.pack();
		this.setVisible(true);

			
		// Be sure to call super and pass it any arguments
		// you want (look at the docs)

		// Create top-level class
	}

	/*
	 * Here is the mainline!  
	 */
	public static void main(String [] argv) {
		new App();
	}

}
