package Cartoon;

import javax.swing.*;
import java.awt.*;




public class MainPanel extends JPanel {
	private DrawingPanel _dp;
	private gfx.Paintbrush myPb;
	private MyTimer _timer;
	private int Counter;
	private JLabel _strokeCounter;
	
	
	public MainPanel (){
		super();
		

		this.setLayout (new java.awt.BorderLayout());
		JPanel southPanel = new JPanel (new GridLayout (0,1));
		
		
		_dp= new DrawingPanel ();
		myPb = new gfx.Paintbrush(_dp, 200, 600);
		_dp.setShape((gfx.Paintbrush)myPb);
		java.awt.Dimension size = new java.awt.Dimension(400, 600);
		_dp.setPreferredSize(size);
		_dp.setSize(size);
		_dp.setBackground (new java.awt.Color(238, 248, 248));
		_timer = new MyTimer(this);
		_timer.start();
		
		
		
		JPanel quitPanel = new JPanel ();
		JPanel textPanel = new JPanel ();
		
		_strokeCounter = new JLabel();
		textPanel.add(_strokeCounter);
		
		
		JButton quit = new QuitButton ();
		quitPanel.add(quit);
	
		
		this.add(_dp,java.awt.BorderLayout.CENTER);
		this.add(southPanel, BorderLayout.SOUTH);
		
		southPanel.add(textPanel);
		southPanel.add(quitPanel);
		
		Counter = 0;
		

	}
	
	public void paintComponent (Graphics g){
		super.paintComponent(g);
		
	
	}
	
	public void move(){
		Counter ++; 
		 _strokeCounter.setText("Time Wasted"+ ":" + " " + String.valueOf(Counter) + " " + "ms");
		 _strokeCounter.setFont(new Font("Futura", Font.PLAIN, 10));
		 
	
		
		_dp.move();
		
	}

	
}
