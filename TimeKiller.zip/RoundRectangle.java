package gfx;

/**
 * This class represents an Rectangle shape.
 */
public class RoundRectangle extends Shape  {


	public RoundRectangle(javax.swing.JPanel container) {
		super ( container, new java.awt.geom.RoundRectangle2D.Double());
	
		
		this.setVisible(true); 
		
		// Call the superclass's constructor with the appropriate parameters
	}
	

}
