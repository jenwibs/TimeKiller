package Cartoon;

public class TimeKillerFrame {
	private TimeKillerFrame _timeKillerFrame; 
	
	public TimeKillerFrame () {
	}
}
