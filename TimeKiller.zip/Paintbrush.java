package gfx;

import java.awt.*;

public class Paintbrush{
	private Rectangle _handle; 
	private RoundRectangle _body; 
	private Ellipse _handleButt;
	private Rectangle _bristles;
	private Rectangle _metal;
	private Rectangle _wetPaint;
	private Rectangle _paintSmudge;
	private double _paintBrushX, _paintBrushY;
	private int _dpWidth, _dpHeight; 
	
	public Paintbrush(javax.swing.JPanel container, int dpWidth, int dpHeight) {
		_dpWidth = dpWidth;
		_dpHeight = dpHeight; 
		_handle = new Rectangle(container); 
		_body = new RoundRectangle (container);
		_handleButt = new Ellipse(container); 
		_bristles = new Rectangle(container);
		_metal = new Rectangle(container);
		_wetPaint = new Rectangle(container);
		_paintSmudge = new Rectangle(container);
		
		_handle.setFillColor (new java.awt.Color(172, 117, 63)); 
		_handle.setSize(15, 100);
		_handle.setBorderColor (new java.awt.Color(172, 117, 63)); 
		_handle.setWrapping(true);
		
		_body.setFillColor (new java.awt.Color(172, 117, 63)); 
		_body.setBorderColor (new java.awt.Color(172, 117, 63)); 
		_body.setSize(50, 25);
		_body.setWrapping(true);
		
		
		
		_handleButt.setFillColor (new java.awt.Color(172, 117, 63)); 
		_handleButt.setSize(15, 15);
		_handleButt.setWrapping(true);
		
		
		_bristles.setFillColor (new java.awt.Color(232, 228, 214)); 
		_bristles.setSize(50, 55);
		_bristles.setBorderColor(new java.awt.Color(232, 228, 214));
		_bristles.setWrapping(true);
		
		_metal.setFillColor (new java.awt.Color(153, 153, 153)); 
		_metal.setSize(50, 10);
		_metal.setBorderColor(new java.awt.Color(153, 153, 153));
		_metal.setWrapping(true);
		
		_wetPaint.setFillColor (new java.awt.Color(220, 237, 241)); 
		_wetPaint.setSize(50, 15);
		_wetPaint.setBorderColor(new java.awt.Color(220, 237, 241));
		_wetPaint.setWrapping(true);
		
		
		 
		 _paintSmudge.setSize(50, 45);
		 _paintSmudge.setWrapping(true);
		 
		 this.setLocation(195,195);
		
	}
	
	public void setLocation (double x, double y){
		double newX = ((x % _dpWidth) +  _dpWidth) % _dpWidth;
		double newY = ((y % _dpHeight) +  _dpHeight) % _dpHeight;
		_handleButt.setLocation(newX, newY);	
		_handle.setLocation(newX, newY-90);
		_body.setLocation(newX-18, newY-100);
		_metal.setLocation(newX-18, newY-100);
		_bristles.setLocation(newX-18, newY-150);
		_wetPaint.setLocation(newX-18, newY-160);
		_paintSmudge.setLocation(newX-18, newY-200);
		_paintBrushX = newX;
		_paintBrushY = newY; 
	
	}
		
	public void move (double deltaX, double deltaY){
		this.setLocation(_paintBrushX+deltaX, _paintBrushY+deltaY);
	
	}
		
	public void paint(Graphics2D brush){
	 
		_handle.paint(brush);
		_body.paint(brush);
		_handleButt.paint(brush);	
		_bristles.paint(brush);
		_metal.paint(brush);
		_wetPaint.paint(brush);
		
		 GradientPaint gp = new GradientPaint(30, 100, (new java.awt.Color(220, 237, 241)), 30, 30, (new java.awt.Color(238, 248, 248)), true);
		 brush.setPaint(gp);
		_paintSmudge.paint(brush);
		
		
		}

		// Call the superclass's constructor with the appropriate parameters
	}