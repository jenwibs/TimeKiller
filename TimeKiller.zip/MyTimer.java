package Cartoon;

public class MyTimer extends javax.swing.Timer {
	private MainPanel _mp; 
	
	public MyTimer(MainPanel panel){
		super (100, null);
		this.addActionListener(new MyMoveListener());
		_mp = panel; 
				
	}

	private class MyMoveListener implements java.awt.event.ActionListener {
		public void actionPerformed( java.awt.event.ActionEvent e){
			_mp.move();
		}
}
}
