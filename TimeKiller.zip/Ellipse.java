package gfx;

/**
 * This class represents an Rectangle shape.
 */
public class Ellipse extends Shape  {


	public Ellipse(javax.swing.JPanel container) {
		super ( container, new java.awt.geom.Ellipse2D.Double());

		this.setVisible(true); 
		
		// Call the superclass's constructor with the appropriate parameters
	}
	

}
