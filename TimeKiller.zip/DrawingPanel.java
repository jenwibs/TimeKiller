package Cartoon;

import java.awt.*;
 

public class DrawingPanel extends javax.swing.JPanel {
	gfx.Paintbrush myPb; 


public DrawingPanel (){

}

public void setShape (gfx.Paintbrush s) {
	myPb = (gfx.Paintbrush)s;
	
}
	  
    
public void paintComponent (Graphics g){
	super.paintComponent(g);
	myPb.paint((Graphics2D)g);
	
}

public void move() {
	myPb.move(0, 2);
	this.repaint();
	
}


	
public Dimension getPreferredSize() {
    return new Dimension(400, 600); // appropriate constants
  }

}
